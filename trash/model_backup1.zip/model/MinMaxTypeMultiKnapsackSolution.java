package khmtk60.miniprojects.multiknapsackminmaxtypeconstraints.model;

import java.util.*;

import localsearch.model.IConstraint;
import localsearch.model.VarIntLS;
import localsearch.search.MoveType;
import localsearch.search.OneVariableValueMove;


public class MinMaxTypeMultiKnapsackSolution {
	private int NOT_USE = -1;
	private int take[];
	private int n;
	private int m;
	private MinMaxTypeMultiKnapsackInputItem items[];
	private MinMaxTypeMultiKnapsackInputBin bins[];
	private double sumW[];
	private double sumP[];
	private HashMap<Integer, Integer> typePerBin[];
	private HashMap<Integer, Integer> classPerBin[];
	private int nTypePerBin[];
	private int nClassPerBin[];
	private int notInB[];
	private double sumV = 0;
	private java.util.Random rand = null;
	private HashMap<Integer, Double> sumWPerR = new HashMap<Integer, Double>();
	private HashMap<Integer, ArrayList<Integer>> itemPerR = new HashMap<Integer, ArrayList<Integer>>();
	private HashMap<Integer, HashSet<Integer>> intersection = new HashMap<Integer, HashSet<Integer>>();
	private double minLoad = Double.MAX_VALUE;
	private double maxLoad = -1;
	private ArrayList<Integer> availR = new ArrayList<Integer>();
	private double maxWR = -1;
	
	public void info() {
		double tmp = 0;
		int maxR = -1;
		
		minLoad = Double.MAX_VALUE;
		int r = -1;
		double w = -1;
		HashSet<Integer> binIndices;
		NOT_USE = m;
		for(int i = 0; i < m; i++) {
			if(maxR < bins[i].getR()) {
				maxR = bins[i].getR();
			}
			if(minLoad > bins[i].getMinLoad()) {
				minLoad = bins[i].getMinLoad();
			}
			if(maxLoad < bins[i].getMinLoad()) {
				maxLoad = bins[i].getMinLoad();
			}
		}
		sumWPerR.clear();
		for (int i = 0; i < n; i++) {
			w = items[i].getW();
			r = items[i].getR();
			binIndices = items[i].getBinIndices();
			tmp += w;
			if(!sumWPerR.containsKey(r)) {
				sumWPerR.put(r, w);
				itemPerR.put(r, new ArrayList<Integer>(i));
				intersection.put(r, new HashSet<Integer>(binIndices));
			} else {
				sumWPerR.replace(r, sumWPerR.get(r) + w);
				itemPerR.get(r).add(i);
				intersection.get(r).retainAll(binIndices);
			}
		}
		
		for (Map.Entry<Integer, HashSet<Integer>> entry : intersection.entrySet()) {
			r = entry.getKey();
		    System.out.print("R = " + r + ", W = " + sumWPerR.get(r) + ", Indices = ");
		    for(int b: entry.getValue()) {
		    	System.out.print(String.format("%.1f", bins[b].getMinLoad()) + " ");
		    }
		    System.out.println();
		}
		System.out.println("Number of items = " + n);
		System.out.println("Number of bins = " + m);
		System.out.println("Sum W (all Bins) = " + tmp);
		System.out.println("Max R (all Bins) = " + maxR);
		System.out.println("Min minload (all Bins) = " + minLoad);
	}
	
	public void preprocess() {
		for(int i = 0; i < m; i++) {
			if(minLoad > bins[i].getMinLoad()) {
				minLoad = bins[i].getMinLoad();
			}
		}
		int r;
		double w;
		sumWPerR.clear();
		availR.clear();
		for (int i = 0; i < n; i++) {
			r = items[i].getR();
			w = items[i].getW();
			if(!sumWPerR.containsKey(r)) {
				sumWPerR.put(r, w);
			} else {
				sumWPerR.replace(r, sumWPerR.get(r) + w);
			}
		}
		for (Map.Entry<Integer, Double> entry : sumWPerR.entrySet()) {
			if(entry.getValue() >= minLoad) {
				availR.add(entry.getKey());
			}
		}
		System.out.println(availR);
	}
	
	
	public void initModel() {
		preprocess();
		info();
		
		rand = new Random();
		take = new int[n];
		sumW = new double[m];
		sumP = new double[m];
		typePerBin = new HashMap[m];
		classPerBin = new HashMap[m];
		nTypePerBin = new int[m];
		nClassPerBin = new int[m];
		notInB = new int[m];
		

		for (int b = 0; b < m; b++) {
			typePerBin[b] = new HashMap<Integer, Integer>();
			classPerBin[b] = new HashMap<Integer, Integer>();
		}
		Arrays.sort(bins, new Comparator<MinMaxTypeMultiKnapsackInputBin>() {

			@Override
			public int compare(MinMaxTypeMultiKnapsackInputBin o1, MinMaxTypeMultiKnapsackInputBin o2) {
				// TODO Auto-generated method stub
				double r = o2.getMinLoad() - o1.getMinLoad();
				if (r > 0) {
					return 1;
				} else if (r < 0) {
					return -1;
				} else {
					return 0;
				}
			}
		});
		/*
		 * for(int b = 0; b < m; b++) {
		 * System.out.println(bins[b].getMinLoad()/(bins[b].getT()*bins[b].getR())); }
		 */
		
		double calW = 0;
		//int b = 1;
		for(int b = m-1; b >= 0; b--) {
			//System.out.println(bins[b].getMinLoad());
        }
		
		for (int i = 0; i < n; i++) {
            if(!availR.contains(items[i].getR())) {
                take[i] = NOT_USE;
                continue;
            }
            
            for(int b = m-1; b >= 0; b--) {
                if(items[i].getBinIndices().contains(bins[b].getId())) {
                    take[i] = b;
                    System.out.println("R = " + items[i].getR());
                    System.out.println("B = " + b + ", min load = " + bins[b].getMinLoad());
                    break;
                }
            }
            
            /*
			if (calW > bins[availBin.get(availBin.size()-1)].getMinLoad()) {
				availBin.remove(availBin.get(availBin.size()-1));
				calW = 0;
			}

			calW += items[i].getW();

			take[i] = availBin.get(availBin.size()-1);*/
			//take[i] = rand.nextInt(m-1);
		}
		/*
		for(b = 0; b < m ; b++) {
			int lenAvailR = availR.size();
			for(int i = 0; i < lenAvailR; i++) {
				int r = availR.get(i);
				if(intersection.get(r).contains(b)) {
					//System.out.println(b + ": " + intersection.get(r));
					//System.out.println(sumWPerR.get(r) + " - " + bins[b].getMinLoad());
				}
				
				if(intersection.get(r).contains(b) && sumWPerR.get(r) >= bins[b].getMinLoad() ) {
					System.out.println("R = " + r + ", b = " + b);
					for (Map.Entry<Integer, ArrayList<Integer>> entry : itemPerR.entrySet()) {
						for(int idx: entry.getValue()) {
							take[idx] = b;
						}
 					}
					availR.remove(i);
					i--;
					lenAvailR--;
				}
			}
		}
		for(int r: availR) {
			for(int bin: intersection.get(r)) {
				if(sumWPerR.get(r) >= bins[bin].getMinLoad() && sumWPerR.get(r) <= bins[bin].getCapacity()) {
					for (int idx: itemPerR.get(r)) {
						take[idx] = b;
 					}
				}
			}
		}*/
		/*
		for(int i = 0; i < n; i++) {
			System.out.println(take[i]);
		}*/

		System.out.println("Init S = " + violations());
	}

	public void resetArray(double a[]) {
		for (int i = 0; i < a.length; i++) {
			a[i] = 0;
		}
	}

	public void resetArray(int a[]) {
		for (int i = 0; i < a.length; i++) {
			a[i] = 0;
		}
	}

	public double violations() {
		double sumViolation = 0;
		resetArray(sumW);
		resetArray(sumP);
		resetArray(notInB);
		resetArray(nTypePerBin);
		resetArray(nClassPerBin);

		int t = 0, r = 0, b = 0;
		for (b = 0; b < m; b++) {
			typePerBin[b].clear();
			classPerBin[b].clear();
		}
		HashSet<Integer> binIndices; 

		for (int i = 0; i < n; i++) {
			b = take[i];
			if(b == NOT_USE) {
				continue;
			}
			binIndices = items[i].getBinIndices();
			if(!binIndices.contains(bins[b].getId())) {
				notInB[b] += 1;
			}
			
			sumW[b] += items[i].getW();
			sumP[b] += items[i].getP();
			t = items[i].getT();
			r = items[i].getR();
			if (!typePerBin[b].containsKey(t)) {
				nTypePerBin[b] += 1;
				typePerBin[b].put(t, 1);
			} else {
				typePerBin[b].replace(t, typePerBin[b].get(t) + 1);
			}
			if (!classPerBin[b].containsKey(r)) {
				nClassPerBin[b] += 1;
				classPerBin[b].put(r, 1);
			} else {
				classPerBin[b].replace(r, classPerBin[b].get(r) + 1);
			}
		}

		for (b = 0; b < m; b++) {
			sumViolation += violations(b);
		}

		return sumViolation;
	}

	public double violations(int b) {
		double sumViolation = 0;

		if (nTypePerBin[b] == 0) {
			return 0;
		}

		sumViolation += Math.max(0, sumW[b] - bins[b].getCapacity());
		sumViolation += Math.max(0, bins[b].getMinLoad() - sumW[b]);
		sumViolation += Math.max(0, sumP[b] - bins[b].getP());
		sumViolation += Math.max(0, nTypePerBin[b] - bins[b].getT());
		sumViolation += Math.max(0, nClassPerBin[b] - bins[b].getR());
		sumViolation += notInB[b];
		return sumViolation;
	}

	public void loadData(String src) {
		MinMaxTypeMultiKnapsackInput input = MinMaxTypeMultiKnapsackInput.loadFromFile(src);
		items = input.getItems();
		bins = input.getBins();
		
		n = items.length;
		m = bins.length;
		for(int b = 0; b < m; b++) {
			bins[b].setId(b);
		}
	}

	public double getSwapDelta(int b, int a, int i) {
		if (b == a) {
			return 0;
		}
		double newSumVOfB = 0, oldSumVOfB = 0;
		double newSumVOfA = 0, oldSumVOfA = 0;
		int t = items[i].getT();
		int r = items[i].getR();
		int deltaTypeB = 0, deltaTypeA = 0;
		int deltaClassB = 0, deltaClassA = 0;
		int deltaNotInB = 0, deltaNotInA = 0;
		HashSet<Integer> binIndices = items[i].getBinIndices(); 
		
		if(b != NOT_USE) {
			oldSumVOfB = violations(b);
			sumW[b] -= items[i].getW();
			sumP[b] -= items[i].getP();
			if(!binIndices.contains(b)) {
				notInB[b] -= 1;
				deltaNotInB = 1;
			}
			if (typePerBin[b].get(t) == 1) {
				nTypePerBin[b] -= 1;
				deltaTypeB = 1;
			}
			if (classPerBin[b].get(r) == 1) {
				nClassPerBin[b] -= 1;
				deltaClassB = 1;
			}
			newSumVOfB = violations(b);
		}
		
		if(a != NOT_USE) {
			oldSumVOfA = violations(a);
			sumW[a] += items[i].getW();
			sumP[a] += items[i].getP();		
			if(!binIndices.contains(a)) {
				notInB[a] += 1;
				deltaNotInA = -1;
			}
			if (!typePerBin[a].containsKey(t)) {
				nTypePerBin[a] += 1;
				deltaTypeA = -1;
			}
			if (!classPerBin[a].containsKey(r)) {
				nClassPerBin[a] += 1;
				deltaClassA = -1;
			}
			newSumVOfA = violations(a);
		}

		if(b != NOT_USE) {
			sumW[b] += items[i].getW();
			sumP[b] += items[i].getP();
			nTypePerBin[b] += deltaTypeB;
			nClassPerBin[b] += deltaClassB;
			notInB[b] += deltaNotInB;
		}
		
		if(a != NOT_USE) {
			sumW[a] -= items[i].getW();
			sumP[a] -= items[i].getP();
			nTypePerBin[a] += deltaTypeA;
			nClassPerBin[a] += deltaClassA;
			notInB[a] += deltaNotInA;
		}
		
		return (newSumVOfB + newSumVOfA) - (oldSumVOfB + oldSumVOfA);
	}
	/*
	 * public int selectMax() { Random rand = new Random(); double maxV = -1;
	 * ArrayList<Integer> maxList = new ArrayList<Integer>(); double v = -1; for(int
	 * b = 0; b < m; b++) { v = violations(b); if(maxV < v) { maxV = v;
	 * maxList.clear(); maxList.add(b); } else if(maxV == v) { maxList.add(b); } }
	 * 
	 * return maxList.get(rand.nextInt(maxList.size())); }
	 */

	class SwapMove {
		int a;
		int b;
		int i;

		public SwapMove(int a, int b, int i) {
			this.a = a;
			this.b = b;
			this.i = i;
		}
	}

	public SwapMove selectMin() {
		Random rand = new Random();
		double minViolation = Double.MAX_VALUE;
		ArrayList<SwapMove> minList = new ArrayList<SwapMove>();
		double v = -1;
		int minV = 0, maxV = NOT_USE; 
		/*
		 * ArrayList<Integer> currentBin = new ArrayList<Integer>(); for(int i = 0; i <
		 * n; i++) { if(take[i] == b) { currentBin.add(i); } }
		 */
		for (int i = 0; i < n; i++) {
			for (int a = minV; a <= maxV; a++) {
				v = getSwapDelta(take[i], a, i);
				if (minViolation > v) {
					minViolation = v;
					minList.clear();
					minList.add(new SwapMove(a, take[i], i));
				} else if (minViolation == v) {
					minList.add(new SwapMove(a, take[i], i));
				}
			}
		}
		System.out.println("Min violation = " + minViolation);

		return minList.get(rand.nextInt(minList.size()));
	}
	
	private void restartMaintainConstraint(int[][] tabu, int minV, int maxV) {

		for (int i = 0; i < n; i++) {
			java.util.ArrayList<Integer> L = new java.util.ArrayList<Integer>();
			for (int a = minV; a <= maxV; a++) {
				if (getSwapDelta(take[i], a, i) <= 0)
					L.add(a);
			}
			int idx = rand.nextInt(L.size());
			take[i] = L.get(idx);
		}
		for (int i = 0; i < tabu.length; i++) {
			for (int j = 0; j < tabu[i].length; j++)
				tabu[i][j] = -1;
		}
		
	}
	
	public void updateBest(){
		
	}
	
	public void tabuSearch(int tabulen, int maxTime, int maxIter,
			int maxStable) {
		double t0 = System.currentTimeMillis();
		int minV = 0, maxV = NOT_USE;
		int D = maxV - minV;
		// System.out.println("n = " + n + ", D = " + D);
		int tabu[][] = new int[n][D + 1];
		for (int i = 0; i < n; i++)
			for (int v = 0; v <= D; v++)
				tabu[i][v] = -1;

		int it = 0;
		maxTime = maxTime * 1000;// convert into milliseconds

		double best = violations();
		int[] x_best = new int[n];
		for (int i = 0; i < n; i++)
			x_best[i] = take[i];

		System.out.println("TabuSearch, init S = " + violations());
		int nic = 0;
		ArrayList<SwapMove> moves = new ArrayList<SwapMove>();
		Random R = new Random();
		while (it < maxIter && System.currentTimeMillis() - t0 < maxTime
				&& (sumV = violations()) > 0) {
			int sel_i = -1;
			int sel_v = -1;
			double minDelta = Double.MAX_VALUE;
			moves.clear();
			
			for (int i = 0; i < n; i++) {
				if(!availR.contains(items[i].getR())) {
					continue;
				}
				for (int a = minV; a <= maxV; a++) {
					if(a != maxV &&!items[i].getBinIndices().contains(bins[a].getId())) {
						continue;
					}
					double delta = getSwapDelta(take[i], a, i);
					// System.out.println("min  =   "+x[i].getMinValue()+"   max =     "+x[i].getMaxValue());
					/*
					 * Accept moves that are not tabu or they are better than
					 * the best solution found so far (best)
					 */
					if (tabu[i][a - minV] <= it
							|| sumV + delta < best) {
						if (delta < minDelta) {
							minDelta = delta;
							sel_i = i;
							sel_v = a;
							moves.clear();
							moves.add(new SwapMove(a, take[i], i));
						} else if (delta == minDelta) {
							moves.add(new SwapMove(a, take[i], i));
						}
					}
				}
			}

			if (moves.size() <= 0) {
				System.out.println("TabuSearch::restart.....");
				restartMaintainConstraint(tabu, minV, maxV);
				// restart(x,tabu);
				nic = 0;
			} else {
				// perform the move
				SwapMove m = moves.get(R.nextInt(moves.size()));
				sel_i = m.i;
				sel_v = m.a;
				take[sel_i] = sel_v;
				tabu[sel_i][sel_v - minV] = it + tabulen;

				System.out.println("Step " + it + ", S = " + violations()
						+ ", best = " + best + ", delta = " + minDelta
						+ ", nic = " + nic);
				// update best
				if ((sumV = violations()) < best) {
					best = sumV;
					for (int i = 0; i < n; i++)
						x_best[i] = take[i];
					updateBest();
				}

				//if (minDelta >= 0) {
				if(violations() >= best){
					nic++;
					if (nic > maxStable) {
						System.out.println("TabuSearch::restart.....");
						restartMaintainConstraint(tabu, minV, maxV);
						nic = 0;
					}
				} else {
					nic = 0;
				}
			}
			it++;
		}
		System.out.println("Step " + it + ", S = " + violations());
		for (int i = 0; i < n; i++)
			take[i] = x_best[i];
		printSolution();
	}

	public void hillClimbingSearch(int nSteps) {
		int i = 1;
		while ((sumV = violations()) > 0 && i <= nSteps) {
			// int b = selectMax();
			SwapMove move = selectMin();

			take[move.i] = move.a;
			System.out.println("Step " + i + ", swap bin = " + move.b + ", bin = " + move.a + ", item = " + move.i
					+ ", S = " + violations());

			i++;
		}
		System.out.println("Step " + i + ", S = " + sumV);
		System.out.println("Result: ");
	}

	public void printSolution() {
		int sum_not_use = 0;
		HashMap<Integer, ArrayList<Integer>> result = new HashMap<Integer, ArrayList<Integer>>();
		for (int i = 0; i < n; i++) {
			if(take[i] == NOT_USE) {
				sum_not_use += 1;
			} else {
				int b = take[i];
				if(!result.containsKey(b)) {
					result.put(b, new ArrayList<Integer>(i));
				} else {
					result.get(b).add(i);
				}
			}
			
		}
		System.out.println("Not use " + sum_not_use + " items");
		for (Map.Entry<Integer, ArrayList<Integer>> entry : result.entrySet()) {
			int b = entry.getKey();
			System.out.print("B = " + bins[b].getId() + ": ");
			for(int item: entry.getValue()) {
				System.out.print(item + " ");
			}
			System.out.println("");
			for(int item: entry.getValue()) {
				System.out.print(items[item].getR() + " ");
			}
			System.out.println("");
			for(int item: entry.getValue()) {
				System.out.print(items[item].getT() + " ");
			}
			System.out.println("");
			violations();
			System.out.println("Capacity violation = " + Math.max(0, sumW[b] - bins[b].getCapacity()));
			System.out.println("Min load violation = " + Math.max(0, bins[b].getMinLoad() - sumW[b]));
			System.out.println("P violation = " + Math.max(0, sumP[b] - bins[b].getP()));
			System.out.println("Type violation = " + Math.max(0, nTypePerBin[b] - bins[b].getT()));
			System.out.println("Class violation = " + Math.max(0, nClassPerBin[b] - bins[b].getR()));
			System.out.println("Indies violation = " + notInB[b]);
		}
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MinMaxTypeMultiKnapsackSolution solution = new MinMaxTypeMultiKnapsackSolution();

		// solution.loadData("src/khmtk60/miniprojects/multiknapsackminmaxtypeconstraints/MinMaxTypeMultiKnapsackInput.json");
		solution.loadData(
				"src/khmtk60/miniprojects/multiknapsackminmaxtypeconstraints/MinMaxTypeMultiKnapsackInput.json");
		solution.initModel();
		//solution.hillClimbingSearch(100);
		//solution.tabuSearch(1, 500, 10000, 500);
	}

}
